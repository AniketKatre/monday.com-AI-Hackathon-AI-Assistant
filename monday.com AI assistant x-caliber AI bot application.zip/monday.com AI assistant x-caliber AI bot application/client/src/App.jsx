import { useRef, useState, useEffect } from "react";
import reactLogo from "./assets/react.svg";
import "./App.css";
import axios from "axios";

const YOU = "You";
const AI = "A.I";

function App() {
const inputRef = useRef();
const [qna, setQna] = useState([]);
const [loading, setLoading] = useState(false);
const [listening, setListening] = useState(false);
const [speaking, setSpeaking] = useState(false);
const audioRef = useRef(null);
const recognitionRef = useRef(null);

    useEffect(() => {
        if (listening) {
          startSpeechRecognition();
        } else {
        stopSpeechRecognition();
        }
    }, [listening]);

    const updateQNA = (from, value) => {
      setQna((qna) => [...qna, { from, value }]);
    };

    const handleSend = () => {
        const question = inputRef.current.value;
        updateQNA(YOU, question);

        setLoading(true);
        axios
          .post("http://localhost:3000/chat", {
            question,
          })
          .then((response) => {
            updateQNA(AI, response.data.answer);
            stopSpeechRecognition(); // Stop speech recognition after processing the query
          })
          .finally(() => {
            setLoading(false);
          });

        inputRef.current.value = ""; // Clear the input field
    };

    const handleKeyPress = (event) => {
        if (event.key === "Enter") {
        handleSend();
        }
    };

    const handleMicClick = () => {
        if (!listening) {
        setListening(true);
        } else {
        setListening(false);
        }
    };

    const startSpeechRecognition = () => {
        recognitionRef.current = new window.webkitSpeechRecognition();

        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = "en-US";

        recognitionRef.current.onstart = () => {
          setListening(true);
        };

        recognitionRef.current.onresult = (event) => {
          const transcript = event.results[event.results.length - 1][0].transcript;
          inputRef.current.value = transcript;
          handleSend();
        };

        recognitionRef.current.onend = () => {
          setListening(false);
        };

        recognitionRef.current.start();
    };

    const stopSpeechRecognition = () => {
        if (recognitionRef.current) {
        recognitionRef.current.stop();
        }
        setListening(false);
    };

    const handleSpeakerClick = () => {
        if (!speaking) {
        speakResponse();
        } else {
        stopSpeaking();
        }
    };

    const speakResponse = () => {
        if (qna.length > 0) {
        const utterance = new SpeechSynthesisUtterance(qna[qna.length - 1].value);
        utterance.onend = () => {
        setSpeaking(false);
        };

          setSpeaking(true);
          window.speechSynthesis.speak(utterance);
        }
    };

    const stopSpeaking = () => {
        window.speechSynthesis.cancel();
        setSpeaking(false);
    };

    const renderContent = (qna) => {
        const value = qna.value;

        if (Array.isArray(value)) {
          return value.map((v) => <p className="message-text">{v}</p>);
        }

        return <p className="message-text">{value}</p>;
    };


return (
    <main className="container">
        
    <div className="chats">
   
    <div className="recieves chat">
      <img
      src="https://cdn-icons-png.flaticon.com/512/4712/4712027.png"
      alt=""
      className="avtar"
      />
      <p>Hi! 👋 It's great to see you!</p>
      </div>
      <br></br>

    {qna.map((qna) => {

        if (qna.from === YOU) {
            return (
            <div className="send chat">
            <img src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png"
              alt="ME : " className="avtar"    />
            <p>{renderContent(qna)}</p>
          </div>
          );
      }
      return (
          <div className="recieve chat">
          <img
            src="https://cdn-icons-png.flaticon.com/512/4712/4712027.png"
            alt=""
            className="avtar"          />
          <p id="scrollbottom">{renderContent(qna)}</p>
          </div>
      );
  })}


  {loading && (
      <div className="recieve chat">
      <img
      src="https://cdn-icons-png.flaticon.com/512/4712/4712027.png"
      alt=""
      className="avtar"
      />
      <p id="scrollbottom">Typing...</p>
      </div>
  )}
  </div>

  <div className="chat-input">
  
  <input   type="text" ref={inputRef}   className="form-control col"  placeholder="Type Something"  onKeyPress={handleKeyPress}  />

  <a href="#">
    <span     className={`icon ${listening ? "active" : ""}`}    role="img"    aria-label="Microphone"    onClick={handleMicClick}    >

         <img class="spinlogo" src="https://i.pinimg.com/originals/67/92/ec/6792ecd4d607173a86608cf4b16a1d51.gif" alt="monday.com" width="60" height="60" />
    
    </span>
  </a>


  <a href="#">
  <span  className={`icon ${speaking ? "active" : ""}`}  role="img"  aria-label="Speaker"  onClick={handleSpeakerClick}  >

      <img class="spinlogo" src="https://cdn.dribbble.com/users/206777/screenshots/15574989/media/0f5f39c35ba72ae1f6dd3fbabaf9ba23.gif" alt="monday.com" width="60" height="60" />
 
  </span>
  </a>


  <button  disabled={loading}  className="btn btn-success"  onClick={handleSend}  >  Send  </button>

  </div>

  </main>
);
}

export default App;
